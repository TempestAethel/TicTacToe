# Progress Knight : Modded

### Introduction
Progress Knight is a text-based incremental game, developed by Ihtasham42, which can be played on your browser.\
Find full detail in the original folder

### Why mod?
just for fun , since i like coding , i want to try something 

### Where to play Progress Knight Original?
Progress Knight can be played on the following sites:  
- [Github Pages](https://ihtasham42.github.io/progress-knight/)  
- [Armor Games](https://armorgames.com/progress-knight-game/19095)
- [Crazy Games](https://www.crazygames.com/game/progress-knight)
